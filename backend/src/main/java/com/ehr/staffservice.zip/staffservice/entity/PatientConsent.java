package com.ehr.staffservice.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

/**
 * Patient Consent entity for tracking signed consents.
 * Maps to patient_consents table.
 */
@Entity
@Table(name = "patient_consents")
@Data
@EqualsAndHashCode(callSuper = false)
public class PatientConsent extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "consent_id")
    private Long id;

    @Column(name = "patient_id", nullable = false)
    private Long patientId;

    @Column(name = "consent_type", nullable = false, length = 100)
    private String consentType = "General Consent";

    @Column(name = "consent_signed", nullable = false)
    private Boolean consentSigned = false;

    @Column(name = "consent_date")
    private LocalDate consentDate;

    @Column(name = "signed_by", length = 200)
    private String signedBy;

    // Common consent types
    public static final String TYPE_GENERAL = "General Consent";
    public static final String TYPE_HIPAA = "HIPAA Consent";
    public static final String TYPE_TREATMENT = "Treatment Consent";
    public static final String TYPE_BILLING = "Billing Consent";
}

