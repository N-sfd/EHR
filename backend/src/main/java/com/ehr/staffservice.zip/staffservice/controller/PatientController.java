package com.ehr.staffservice.controller;

import com.ehr.staffservice.dto.PatientDto;
import com.ehr.staffservice.service.PatientService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/patients")
@RequiredArgsConstructor
public class PatientController {

    private final PatientService service;
    private final EntityManager entityManager;

    @PostMapping
    public ResponseEntity<PatientDto> create(@Valid @RequestBody PatientDto dto) {
        PatientDto created = service.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<PatientDto>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PatientDto> get(@PathVariable Long id) {
        return ResponseEntity.ok(service.get(id));
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<PatientDto> getByPatientCode(@PathVariable String code) {
        return ResponseEntity.ok(service.getByPatientCode(code));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PatientDto> update(@PathVariable Long id,
                                            @RequestBody PatientDto dto) {
        // Removed @Valid to allow partial updates without validation errors
        // Validation will be handled in the service layer for required fields
        return ResponseEntity.ok(service.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/photo")
    public ResponseEntity<PatientDto> uploadPhoto(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        String photoUrl = request.get("photoUrl");
        if (photoUrl == null || photoUrl.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        
        PatientDto patient = service.get(id);
        patient.setPhotoUrl(photoUrl);
        PatientDto updated = service.update(id, patient);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}/photo")
    public ResponseEntity<PatientDto> removePhoto(@PathVariable Long id) {
        PatientDto patient = service.get(id);
        patient.setPhotoUrl(null);
        PatientDto updated = service.update(id, patient);
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/{id}/image")
    public ResponseEntity<byte[]> getImage(@PathVariable Long id) {
        PatientDto patient = service.get(id);
        String photoUrl = patient.getPhotoUrl();
        
        if (photoUrl == null || photoUrl.trim().isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        // Handle data URLs (data:image/jpeg;base64,...)
        if (photoUrl.startsWith("data:image")) {
            try {
                String[] parts = photoUrl.split(",");
                if (parts.length == 2) {
                    String base64Data = parts[1];
                    byte[] imageBytes = java.util.Base64.getDecoder().decode(base64Data);
                    
                    // Extract content type from data URL
                    String contentType = "image/jpeg"; // default
                    String headerPart = parts[0];
                    if (headerPart.contains("image/png")) {
                        contentType = "image/png";
                    } else if (headerPart.contains("image/gif")) {
                        contentType = "image/gif";
                    } else if (headerPart.contains("image/webp")) {
                        contentType = "image/webp";
                    }
                    
                    org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
                    headers.setContentType(org.springframework.http.MediaType.parseMediaType(contentType));
                    headers.setContentLength(imageBytes.length);
                    
                    return new ResponseEntity<>(imageBytes, headers, HttpStatus.OK);
                }
            } catch (Exception e) {
                return ResponseEntity.notFound().build();
            }
        }
        
        // If it's a regular HTTP/HTTPS URL, redirect to it
        if (photoUrl.startsWith("http://") || photoUrl.startsWith("https://")) {
            org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
            headers.setLocation(java.net.URI.create(photoUrl));
            return new ResponseEntity<>(headers, HttpStatus.FOUND);
        }
        
        // If it's a long base64 string without prefix, assume it's base64 and decode it
        if (photoUrl.length() > 100) {
            try {
                byte[] imageBytes = java.util.Base64.getDecoder().decode(photoUrl);
                org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
                headers.setContentType(org.springframework.http.MediaType.IMAGE_JPEG);
                headers.setContentLength(imageBytes.length);
                return new ResponseEntity<>(imageBytes, headers, HttpStatus.OK);
            } catch (Exception e) {
                return ResponseEntity.notFound().build();
            }
        }
        
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}/consent")
    public ResponseEntity<Map<String, Object>> getConsent(@PathVariable Long id) {
        Map<String, Object> consent = new HashMap<>();
        consent.put("patientId", id);
        
        try {
            Query query = entityManager.createNativeQuery(
                "SELECT consent_signed, consent_date, consent_type, signed_by " +
                "FROM patient_consents " +
                "WHERE patient_id = :patientId AND consent_signed = true " +
                "ORDER BY consent_date DESC LIMIT 1"
            );
            query.setParameter("patientId", id);
            
            @SuppressWarnings("unchecked")
            List<Object[]> results = query.getResultList();
            
            if (!results.isEmpty()) {
                Object[] result = results.get(0);
                consent.put("consentSigned", result[0] != null ? (Boolean) result[0] : false);
                consent.put("consentDate", result[1] != null ? result[1].toString() : null);
                consent.put("consentType", result[2] != null ? result[2].toString() : "General Consent");
                consent.put("signedBy", result[3] != null ? result[3].toString() : null);
            } else {
                // No consent found
                consent.put("consentSigned", false);
                consent.put("consentDate", null);
                consent.put("consentType", "General Consent");
                consent.put("signedBy", null);
            }
        } catch (Exception e) {
            // If query fails, return default (not signed)
            consent.put("consentSigned", false);
            consent.put("consentDate", null);
            consent.put("consentType", "General Consent");
            consent.put("signedBy", null);
        }
        
        return ResponseEntity.ok(consent);
    }
}

