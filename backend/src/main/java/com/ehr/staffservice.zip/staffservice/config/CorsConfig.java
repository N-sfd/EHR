package com.ehr.staffservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * CORS configuration for cross-origin requests.
 * 
 * IMPORTANT: When allowCredentials is true, allowedOrigins cannot be "*".
 * Must specify exact origins (e.g., "http://localhost:4200").
 * 
 * This configuration enables:
 * - Credentials (cookies) to be sent cross-origin
 * - Required for SMART_SESSION cookie to work between frontend (4200) and backend (8087)
 */
@Configuration
public class CorsConfig {

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {

            @Override
            public void addCorsMappings(@NonNull CorsRegistry registry) {
                // API endpoints with credentials support (for SMART flow)
                registry.addMapping("/api/**")
                        .allowedOrigins("http://localhost:4200", "http://localhost:4300", "http://localhost:63132")  // Admin Portal, MyChart Portal, and Angular dev server origins
                        .allowedHeaders("*")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                        .allowCredentials(true)  // Required for HttpOnly cookies (SMART_SESSION)
                        .maxAge(3600);
                
                // Fallback for other endpoints (no credentials)
                registry.addMapping("/**")
                        .allowedOrigins("*")
                        .allowedHeaders("*")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                        .allowCredentials(false)
                        .maxAge(3600);
            }
        };
    }
}
