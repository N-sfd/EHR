package com.ehr.staffservice.controller;

import com.ehr.staffservice.dto.PatientDashboardDto;
import com.ehr.staffservice.service.DashboardService;
import com.ehr.staffservice.service.SessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Patient dashboard controller (Epic-style).
 * Provides aggregated dashboard data for MyChart home page.
 */
@Slf4j
@RestController
@RequestMapping("/api/patient/dashboard")
@RequiredArgsConstructor
@PreAuthorize("hasRole('PATIENT')")
public class PatientDashboardController {

    private final DashboardService dashboardService;

    /**
     * GET /api/patient/dashboard
     * Returns Epic-style dashboard data: patient summary, counts, next appointment, alerts, care team.
     */
    @GetMapping
    public ResponseEntity<PatientDashboardDto> getDashboard(
            @RequestAttribute(value = "sessionData", required = false) SessionService.SessionData session) {
        
        log.debug("Dashboard request received - session present: {}, patientId: {}", 
                session != null, 
                session != null ? session.getPatientId() : "null");
        
        if (session == null || session.getPatientId() == null) {
            log.warn("Dashboard request without valid session - session: {}, patientId: {}, userId: {}, role: {}", 
                    session != null ? "present" : "null",
                    session != null ? session.getPatientId() : "null",
                    session != null ? session.getUserId() : "null",
                    session != null ? session.getRole() : "null");
            // Return 401 with a clear error message
            return ResponseEntity.status(org.springframework.http.HttpStatus.UNAUTHORIZED)
                    .body(null); // Frontend will handle the 401 status
        }
        
        try {
            Long patientId = session.getPatientId();
            log.info("Building dashboard for patientId: {} (userId: {}, role: {})", 
                    patientId, session.getUserId(), session.getRole());
            
            long startTime = System.currentTimeMillis();
            PatientDashboardDto dashboard = dashboardService.getPatientDashboard(patientId);
            long duration = System.currentTimeMillis() - startTime;
            
            log.info("Dashboard built successfully for patientId: {} - Duration: {}ms - Tiles: {}, Alerts: {}, CareTeam: {}", 
                    patientId, 
                    duration,
                    dashboard.getTiles() != null ? dashboard.getTiles().size() : 0,
                    dashboard.getAlerts() != null ? dashboard.getAlerts().size() : 0,
                    dashboard.getCareTeam() != null ? "present" : "null");
            
            return ResponseEntity.ok(dashboard);
        } catch (com.ehr.staffservice.exception.ResourceNotFoundException e) {
            log.error("Patient not found for dashboard - patientId: {} - Message: {} - Stack trace: {}", 
                    session.getPatientId(), 
                    e.getMessage(),
                    getStackTrace(e));
            throw e; // Re-throw to let GlobalExceptionHandler handle it (returns 404)
        } catch (RuntimeException e) {
            Long patientIdForLog = session != null ? session.getPatientId() : null;
            log.error("RuntimeException building dashboard for patientId: {} - Exception: {} - Message: {} - Cause: {} - Stack trace: {}", 
                    patientIdForLog, 
                    e.getClass().getSimpleName(), 
                    e.getMessage(),
                    e.getCause() != null ? e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage() : "none",
                    getStackTrace(e));
            throw new RuntimeException("Failed to build dashboard: " + e.getMessage(), e);
        } catch (Exception e) {
            Long patientIdForLog = session != null ? session.getPatientId() : null;
            log.error("Unexpected error building dashboard for patientId: {} - Exception: {} - Message: {} - Cause: {} - Stack trace: {}", 
                    patientIdForLog, 
                    e.getClass().getSimpleName(), 
                    e.getMessage(),
                    e.getCause() != null ? e.getCause().getClass().getSimpleName() + ": " + e.getCause().getMessage() : "none",
                    getStackTrace(e));
            throw new RuntimeException("Failed to build dashboard: " + e.getMessage(), e);
        }
    }
    
    private String getStackTrace(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }
}

